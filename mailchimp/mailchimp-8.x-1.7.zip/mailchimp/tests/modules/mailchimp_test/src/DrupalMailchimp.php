<?php

namespace Drupal\mailchimp_test;

class DrupalMailchimp {

  public function __construct($apikey = NULL, $opts = array()) {

  }

}
